
#include <iostream>
#include <Windows.h>
using namespace std;

void gotoxy(int x, int y){
	
	COORD coord;
	coord.X = x;
	coord.Y = y;
	
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
	
}

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() 
{
    int n, i,j,c;
    char main='y';
    
    cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
	cout<<"\n\xBA                                                  \xBA";
	cout<<"\n\xBA                    WELCOME!!!                    \xBA";
	cout<<"\n\xBA                                                  \xBA";
	cout<<"\n\xBA                                                  \xBA";
	cout<<"\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
	cout<<"\n";
	system("PAUSE");
	system("CLS");
    
    while (main=='Y'||main=='y')
    {	float high=0,sechigh=0,low=99999, seclow=99999;
	    cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
		cout<<"\n\xBA                                                  \xBA";
		cout<<"\n\xBA         Enter the size of the array              \xBA";
		cout<<"\n\xBA                                                  \xBA";
		cout<<"\n\xBA                                                  \xBA";
		cout<<"\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
		cout<<"\n";
		float arr[n];
		cout<<">> ";
		cin >> n;
		system("CLS");
		
		if(n<=1)
		{
			gotoxy(20,10);cout<<"System Error: Can't find Largest and/or Lowest Number if there's only no/one value.";
			gotoxy(0,30);return 0;
		}
		
		
		for (i = 0; i<n; ++i)
		{
			cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			cout<<"\n\xBA                                                  \xBA";
			cout<<"\n\xBA                Enter index ["<<i<<"]                   \xBA";
			cout<<"\n\xBA                                                  \xBA";
			cout<<"\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
			cout<<"\n";
			cout<<">> ";
        	cin >> arr[i];
        	
        	system("CLS");
    	}
    
         for (i = 0; i<n; ++i)
        {        	
              if (arr[i]>high)
              {
                     high = arr[i];
              }
        }
       		//finding second largset
         for (i = 0; i<n; ++i)
        {
              if (arr[i]>sechigh)
              {
                     if (arr[i] == high)
                           continue;              //Ignoring largest in order to get second largest
                     sechigh = arr[i];
              }
              
		}
		for (i=0;i<n;++i){
			if (low>arr[i])
              {
                     low = arr[i];
              }
		}
		
		for (i=0;i<n;++i)
		{
			if (seclow>arr[i])
              {
                     if (arr[i] == low)
                           continue;              //Ignoring largest in order to get second largest
                     seclow = arr[i];
              }
		}
  if(i=!cin)
        	{
        		gotoxy(20,10);cout<<"Invalid Input";
				gotoxy(0,30);return 0;
			}
		system("CLS");
		
		cout<<"Entered Values>>";
		for (i = 0; i<n; ++i)
			{
			cout<<"|"<<arr[i]<< "| ";
			}
			cout<<"\n";
			cout<<"\n\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			cout<<"\n\xBA                                                  \xBA";
			cout<<"\n\xBA                    RESULTS                       \xBA";
			cout<<"\n\xBA             Highest element: "<<high<<"                   \xBA";
			cout<<"\n\xBA             Second Highest Element: "<<sechigh<<"            \xBA";
			cout<<"\n\xBA             Lowest Element: "<<low<<"                    \xBA";
			cout<<"\n\xBA             Second Lowest Element: "<<seclow<<"             \xBA";
			cout<<"\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
    		cout<< "\n" << endl;
    		
    		system("PAUSE");
			system("CLS");    
    		cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
			cout<<"\n\xBA                                                  \xBA";
			cout<<"\n\xBA        Do you wanna go back to try again?        \xBA";
			cout<<"\n\xBA                  Press [Y] if Yes                \xBA";
			cout<<"\n\xBA                                                  \xBA";
			cout<<"\n\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";
	        cout<<"\n>>";
			cin>>main;
			
	        system("CLS");
	    }
    return 0;
}
