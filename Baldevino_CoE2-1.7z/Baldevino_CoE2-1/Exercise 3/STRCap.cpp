#include <iostream>
#include <string.h>
using namespace std;

int main()
{
  
   
   char sentence[99];
   
   cout << "Please enter a sentence.\n";
   cin.getline(sentence,99); 

   sentence[0] = toupper(sentence[0]);
   
   for (int i = 1; i < sentence[i]; i++)
   {
        if ( sentence[i - 1] == ' ' )
            sentence[i] = toupper( sentence[i] );
        else
            sentence[i] = tolower(sentence[i]);
   }

   cout << sentence<<"\n";
   system("pause");
   
   return 0;
}
