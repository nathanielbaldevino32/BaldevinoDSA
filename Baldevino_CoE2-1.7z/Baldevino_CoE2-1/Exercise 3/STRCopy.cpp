#include <iostream>
#include <string.h>
using namespace std;

int main() 
{
	char str1[20], str2[20];
	
	cout<<"Welcome!\nOriginal Input: ";
	cin>>str1;
	cout<<"\nInput to be copied: ";
	cin>>str2;
	system("cls");
	
	strcpy(str1,str2);
	
	cout<<"After copying ":
	cout<<str1;
	cout<<"\n";
	system("PAUSE");
	
	
	return 0;
}
