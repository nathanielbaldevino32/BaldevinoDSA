#include <iostream>
using namespace std;


int main() 
{
	char str1[20], str2[20];
	char main='y';
	
		while (main=='Y'||main=='y')	
		{
			cout<<"Welcome!\nPlease enter the two inputs to be compared...\n";
			cout<<"Input #1: ";cin>>str1;
			cout<<"\nInput #2: ";
			cin>>str2;
		
			system("CLS");
		
			strcmp(str1,str2);
			if(strcmp(str1,str2))
			{
				cout<<"The inputs aren't equal.";
			}
			else
			{
				cout<<"The inputs are equal.";
			}
			
			cout<<"\n";
			system("PAUSE");
		
			system("cls");
	
			cout<<"Wanna try again?\n";
			cout<<"Enter [Y] if yes\n";
			cout<<">>";
			cin>>main;
			system("CLS");
		}
	
	return 0;
}









