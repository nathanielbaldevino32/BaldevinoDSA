#include <iostream>
using namespace std;

struct Item
{
	int code;
	char name[50];
	double price;
};

void displayItem(Item* _itm);
void newLine();

int main()
{
	struct Item* itm;
	itm = new Item;
	cout<< "Enter Item Information: \n";
	cout<< "Code: ";
	cin>> itm->code;
	newLine();
	cout<< "Price: ";
	cin>> itm->price;
	
	system("pause>0");
	return 0;
}

void display(Item* itm){
	
	cout<< "\n\nDisplay Item Information:\n";
	cout<< "Code: "<< itm->code << endl;
	cout<< "Name: "<< itm->name << endl;
	cout<< "Price: "<< itm->price << endl;
}

void newLine()
{
	char s;
	do{cin.get(s);}while(s!='\n');
}

