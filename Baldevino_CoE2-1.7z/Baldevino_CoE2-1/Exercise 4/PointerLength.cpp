#include <iostream>
using namespace std;

int main() 
{
  char str[99], *pt;
  int i = 0;
  
  cout<<"Length of String \n";
  cout<<"Enter string : ";
  cin>>str;
  
  pt = str;
  
  while (*pt != '\0') 
  {
    i++;
    pt++;
  }
  cout<<"\nLength of String : "<<i;
  

  return 0;
}
