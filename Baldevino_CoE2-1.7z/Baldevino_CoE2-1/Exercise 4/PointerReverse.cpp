#include <iostream>
#include <string.h>
using namespace std;

int main() 
{ 

    char str[100] = "Data Structure and Algorithms"; 
    cout<<"Entered string: "<< str; 
  
    reverseString(str); 
  
    cout<<"\nReverse of the string: "<< str; 
  
    return 0; 
} 

void reverseString(char* str) 
{ 
    int l, i; 
    char *begin_ptr, *end_ptr, ch; 
  
  
    l = strlen(str); 
  
  
    begin_ptr = str; 
    end_ptr = str; 
  

    for (i = 0; i < l - 1; i++) 
        end_ptr++; 
  
 
    for (i = 0; i < l / 2; i++) { 
  
  
        ch = *end_ptr; 
        *end_ptr = *begin_ptr; 
        *begin_ptr = ch; 
  
   
        begin_ptr++; 
        end_ptr--; 
    } 
} 
  

