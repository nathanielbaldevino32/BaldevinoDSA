#include<iostream>
#include <iostream>
#include <Windows.h>
using namespace std;

void gotoxy(int x, int y){
	
	COORD coord;
	coord.X = x;
	coord.Y = y;
	
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
	
}

int x=0,y=0,z, check;

float row, col;

bool go = true;



void printArray();

void printRow();

void printCol();

void errorHandling();

void repeat();






int main(){

	printArray();

		cout << "---------------------------------------------------------------------------------------\n";		

		cout << "Select row number(1-10): "; 

				cin >> row;

				check = int(row);

		if(row < 1 || row > 10 || check != row)
		{

 			errorHandling();

		}

		else if(cin.fail())
		{

			errorHandling();

		}
		else
		{

				printRow();

				cout << "\nSelect column number(1-10): "; 

				cin >> col; 

				check = int(col);

					if(col < 1 || col > 10 || check != col)
					{

						errorHandling();

					}
					else if(cin.fail())
					{

						errorHandling();

					}
					else
					{

						printCol();

						if(go)
						{
							cout << "Press enter/enter a key to continue!";


							cin.clear();

							cin.ignore(100,'\n');	
						}
			repeat();
		}
	}
}

void printCol()
{

	for(x = 1; x<= 10; x++)
	{
		for(y =1; y <= 10; y++)
		{
			if(x == col)
			{
				if(x == y)
				{
					cout << "\t1\n";
				}
				else
				{
					cout << "\t0\n";
				}
			}
		}
	}
}

void printRow()
{
	for(x = 1; x<= 10; x++)
	{

		for(y =1; y <= 10; y++)
		{

			if(y == row)
			{

				if(x == y)
				{
					cout << "1\t";
				}
				else
				{
					cout << "0\t";
				}
			}
		}
	}
}

void printArray()
{
	int arr[10][10];

	cout << "\t";

	for(x = 1; x <= 10; x++)
	{

		cout << "COL" << x <<"\t";

	}

	cout << endl;

	for(x = 1; x <= 10; x++)
	{

		cout << "ROW" << x << "\t";

		for(y = 1; y <= 10; y++)
		{

			if(x==y){

				z = arr[x-1][y-1] = 1;

				cout << "  "<< z << "\t";

			}

			else{

				z = arr[x-1][y-1] = 0;

				cout << "  " << z << "\t";

			}
		

			if(y%10==0)
			{
				cout << endl;
			}
		}
	}
}



void errorHandling()
{

	go = true;

	cin.clear();

	cin.ignore(100,'\n');

	system("cls");

	cout <<"Invalid Input!\nEnter whole number(1-10)\n";

	system("pause");

	system("cls");

	main();

}

void repeat()
{

	cin.ignore(100,'\n');

	char yesNo;

	cout << "\nTry Again? (y/n): " ; cin >> yesNo;

	system("cls");

	if (yesNo == 'y' || yesNo == 'Y')
	{
		go = true;

		main();
	}
	else if(yesNo == 'n' || yesNo == 'N')
	{
		cout << "Thank You!...";
		system("exit");
	}
	else
	{

		cout << "Invalid Choice Exiting...";

		system("exit");
	}
}
