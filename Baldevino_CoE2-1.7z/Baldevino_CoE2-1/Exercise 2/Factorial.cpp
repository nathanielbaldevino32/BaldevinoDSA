#include <iostream>
using namespace std;
#include <Windows.h>

void gotoxy(int x, int y){
	
	COORD coord;
	coord.X = x;
	coord.Y = y;
	
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);
	
}

int factorial(int);

int main() 
{	
	int x,y;	
	char again='y';
				
					while(again=='Y'||again=='y')
					{
						  
					  	gotoxy (48,1);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
						gotoxy (48,2);cout<<"\xBA                         \xBA";
						gotoxy (48,3);cout<<"\xBA                         \xBA";
						gotoxy (48,4);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";	
	        			
					    gotoxy (53,2);cout<<"Input your number";
				        gotoxy (53,3);cout<<">>";
				        gotoxy (55,3);cin>>x;
		
			   	        y=factorial(x);

			            if (y>0)
			   			gotoxy (35,5);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
						gotoxy (35,6);cout<<"\xBA               \xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB             \xBA";
						gotoxy (35,7);cout<<"\xBA               \xBA                    \xBA             \xBA";
						gotoxy (35,8);cout<<"\xBA               \xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC             \xBA";
						gotoxy (35,9);cout<<"\xBA                                                  \xBA";
						gotoxy (35,10);cout<<"\xBA                                                  \xBA";
						gotoxy (35,11);cout<<"\xBA                                                  \xBA";
						gotoxy (35,12);cout<<"\xBA               \xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB             \xBA";
						gotoxy (35,13);cout<<"\xBA               \xBA                    \xBA             \xBA";
						gotoxy (35,14);cout<<"\xBA               \xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC             \xBA";
						gotoxy (35,15);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC";	
				
						gotoxy (53,7);cout<<"Factorial Function";
						gotoxy (52,10);cout<<"Your number: ";
						gotoxy (64,10);cout<<x;
						gotoxy (52,13);cout<<"Answer: ";
						gotoxy (59,13);cout<<y;		        						   		
					  
							
	        		
	        			gotoxy (35,16);cout<<"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB";
						gotoxy (35,17);cout<<"\xBA                  Wanna Try Again?                 \xBA";
						gotoxy (35,18);cout<<"\xBA                     [ Y / N]                      \xBA";
						gotoxy (35,19);cout<<"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n";	
	        			
						gotoxy (58,20);cout<<"\xC9\xCD\xCD\xCD\xCD\xBB";
						gotoxy (58,21);cout<<"\xBA    \xBA";
						gotoxy (58,22);cout<<"\xC8\xCD\xCD\xCD\xCD\xBC";
	        		
	        			gotoxy (59,21);cout<<">>";
						gotoxy (61,21);cin>>again;
						system("CLS");					  
					}
	
						again='y';
						system("CLS");			   		    
	return 0;
}

int factorial(int x)
	{	int ans=1;
		if(x<0)
			{
				cout<<"You can't get the factorial of a negative number, try to input a positive number.";
				return 0;
			}
		else if (x>0)
		{
			 while(x>=1)
			 	{
			 		ans=ans*x;
			 		x--;
				}
				return ans;
		}
		else 
			{
				return 1;				
			}
	}
